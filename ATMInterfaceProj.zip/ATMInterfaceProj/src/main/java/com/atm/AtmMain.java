/**
 * This is a Complete Java based ATM system created in Java.
 *  Uses: File Handling, Exception Handling, MySQL Databases,Different Classes.
 *  This Project is to make an Automated Teller Machine
 *  with User's Account Number,Pin Number and Password with that
 *  users are able to check their Account balance, Withdraw, Deposit money and
 *  view their Statement and
 *  they can change their Pin Number and also New users can generate new Pin Number.
 *  Validations using If else, Loops and Many more :)
 * This information then gets updated in a MySQL databases I set up locally.
 * 
 * @author Priyadharshini K
 */
//import required classes and packages
package com.atm;
import java.util.Scanner;

//Class Declaration to implement ATM functionality
public class AtmMain 
{
	//main method starts
	public static void main(String[] args)
	{
		//Scanner class object to get choice of user
		Scanner sc=new Scanner(System.in);
		while (true)
		{
		//Creating ATM Banking Menu
			System.out.println("*****************************");
			System.out.println("\tWELCOME TO ABC ATM");
			System.out.println("*****************************");
			System.out.println("Please Enter Your Choice\n");
			System.out.println("1.Login to Start Transaction");
			System.out.println("2.Generate/Change PIN Number");
			//get choice from the user
			int ch=sc.nextInt();
			switch(ch)
			{
			case 1: AtmOperation.loginAccount();
					break;
			case 2:	
					System.out.println("ENTER YOUR OPTION");
					System.out.println("1.GENERATE NEW PIN NUMBER ");
					System.out.println("2.CHANGE MY PIN NUMBER");
					System.out.println("3.EXIT");
					int choice=sc.nextInt();
					//Get Input from the User
					if(choice==1)
					{
					AtmOperation.setPinMethod();
					}
					else if(choice==2)
					{
					AtmOperation.changePinMethod();
					}
					else if(choice==3)
					{
						//exit from the user
						break;
					}
					else 
					{
						//show custom error message
						 System.out.println("Oops!! Invalid Option");
					}
					break;
				default:System.out.println("Invalid choice");
			}
		
			System.out.println("Do You want to Continue Again ? (Yes/No)");
			String choice=sc.next();
			if(choice.equalsIgnoreCase("no"))
			{
				System.out.println("ThankYou for Using Our ABC ATM !!!");
				System.out.println("\tPLEASE VISIT AGAIN");
				System.out.println("***** HAVE A NICE DAY :) *****");
				break;
			}
		}
		sc.close();
		}
	}

