package com.atm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class AtmOperation 
{
	//Connection Variables
	static Connection scon=null;
	static ResultSet rs=null;
	static Statement st=null;


	static Scanner sc=new Scanner(System.in);
	static int Customer_pin;
	static int Account_Number;
	static String Customer_name;
	static float BalanceAmount;
	static Map<Float,String> ministmt=new HashMap<Float, String>();

	public static void loginAccount()
	{
		try
		{
			scon=DBConnect.getConnection();
			st=scon.createStatement();

			System.out.println("\tPLEASE ENTER YOUR 4-DIGIT\nPERSONAL IDENTIFICATION NUMBER");
			Customer_pin=sc.nextInt();
			String sql="select * from customer where Customer_pin="+Customer_pin;
			rs=st.executeQuery(sql);
			if(rs.next())
			{
				System.out.println("*************************");
				System.out.println("Welcome "+rs.getString(3)+"."+rs.getString(4)+" !!!");
				System.out.println("*************************");
				displayMenu();

			}
			else
			{
				System.out.println("XXX invalid pin XXX");
			}
		}


		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private static void displayMenu() throws SQLException
	{

		System.out.println("PLEASE ENTER YOUR DESIRED OPTION\n");
		System.out.println("1.CHECK BALANCE\t\t2.WITHDRAW MONEY\n3.DEPOSIT MONEY\t\t4.VIEW MINI-STATEMENT\n5.EXIT");
		System.out.println("**********************************");
		int option =sc.nextInt();
		switch(option)
		{
		case 1:AtmOperation.balanceEnquiry();
		break;
		case 2:
			System.out.println("Enter The Amount to Withdraw in Multiple of\n\t100,200,500 and 2000");
			float amount=sc.nextFloat();
			//Check the Input Amount
			if(amount%100==0)
			{

				AtmOperation.withdrawMoney(amount);

			}
			else
			{
				System.out.println("XXX Amount Cannot Withdraw XXX");
				System.out.println("Please Enter the Amount Only in Multiple of 100,200,500 and 2000");
			}
			break;
		case 3:
			System.out.println("Enter the Amount to Deposit in Multiple of\n\t100,200,500 and 2000");
			float Damount=sc.nextFloat();
			//Check the Input Amount
			if(Damount%100==0)
			{

				AtmOperation.depositMoney(Damount);
			}
			else
			{
				System.out.println("XXX Amount Cannot Deposit XXX");
				System.out.println("Please Enter the Amount Only in Multiple of 100,200,500,2000");
			}
			break;

		case 4:	viewstatement();
		break;
		case 5:	System.out.println("Your Transaction Cancelled");
		break;
		default:
			System.out.println("Oops!!! Invalid Choice");
		}
	}

	public static void balanceEnquiry()
	{
		try {
			//connect to database
			scon=DBConnect.getConnection();
			st=scon.createStatement();
			//Get results
			String sql="select * from account where Customer_pin="+Customer_pin;
			rs=st.executeQuery(sql);

			while(rs.next())
			{

				System.out.println("Your Available Balance is\t:Rs."+rs.getFloat(3));
			} 
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public static void withdrawMoney(float amount) 
	{
		try {
			scon=DBConnect.getConnection();
			st=scon.createStatement();
			String sql="select * from account where Customer_pin="+Customer_pin;
			rs=st.executeQuery(sql);
			if(rs.next())
			{
				if(amount<rs.getFloat(3))
				{
					float Withdraw_amount =rs.getFloat(3)-amount;
					String sql1="update account set Balance_Amount="+Withdraw_amount+"where Customer_pin="+Customer_pin;
					int i=st.executeUpdate(sql1);
					if(i>0)
					{
						LocalDateTime current=LocalDateTime.now();
						System.out.println("******************************");
						System.out.println(" "+current+"\n");

						System.out.println("Amount Withdraw Successfully!!!\nPlease Take Your Cash Rs."+amount+"\n");

						ministmt.put(amount," .Rs is withdrawn\t@ "+current);
						System.out.println("***************\nAfter Withdraw Current Balance\n***************\n");
						balanceEnquiry();
					}
				}
				else
				{
					System.out.println("Xxx Insufficient Balance xxX");
				}
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}	
	}

	public static void depositMoney(float Damount) 
	{
		try {
			scon=DBConnect.getConnection();
			st=scon.createStatement();
			String sql="select * from account where Customer_pin="+Customer_pin;
			rs=st.executeQuery(sql);
			if(rs.next())
			{
				float Deposit_amount =rs.getFloat(3)+Damount;
				String sql1="update account set Balance_Amount="+Deposit_amount+"where Customer_pin="+Customer_pin;
				int i=st.executeUpdate(sql1);
				if(i>0)
				{
					LocalDateTime current=LocalDateTime.now();
					System.out.println("******************************");
					System.out.println(" "+current+"\n");
					System.out.println("Rs."+Damount+" is  Deposited in Your Account Successfully\n");
					ministmt.put(Damount," .Rs is deposited\t@ "+current);
					System.out.println("***************\nAfter Deposit Current Balance\n***************\n");
					balanceEnquiry();
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private static void viewstatement()
	{
		scon=DBConnect.getConnection();
		System.out.println("****************\tTRANSACTION STATEMENT\n");
		for(Map.Entry<Float,String> m:ministmt.entrySet())
		{
			System.out.println(m.getKey()+""+m.getValue());
			System.out.println("****************\n");
		}
	}

	public static void setPinMethod()
	{

		try
		{
			//Get Connection
			scon=DBConnect.getConnection();
			st=scon.createStatement();
			System.out.println("Enter Your Account Number");
			int accno=sc.nextInt();
			//CHECK WHETHER THE ACCOUNT NUMBER IS EXIST OR NOT
			String sql="select * from customer where Account_Number="+accno;
			rs=st.executeQuery(sql);
			if(rs.next())
			{
				//CHECK THE USER DOESN'T HAVE A PIN NUMBER ALREADY
				if(rs.getString(2)==null)
				{
					System.out.println("************************");
					System.out.println("Welcome "+rs.getString(3)+"."+rs.getString(4));
					System.out.println("************************");
					System.out.println("Enter Your Password");
					String pass=sc.next();
					System.out.println("Enter New Pin");
					int Cpin=sc.nextInt();
					String sq="update customer set Customer_pin="+Cpin+" where Account_Password='"+pass+"'";
					int i=st.executeUpdate(sq);
					if(i>0)
					{
						String sqlnewp="update account set Customer_pin="+Cpin+" where Account_Number="+accno;
						st.executeUpdate(sqlnewp);
						System.out.println("PIN GENERATED SUCCESSFULLY");
					}
					else
					{
						System.out.println("Incorrect Password");
					}
				}
				else
				{
					System.out.println("Already You have A Pin\tCannot Generate New Pin");
				}
			}
			else
			{
				System.out.println("XXX InValid  Account Number XXX");
			}
		}

		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public static void changePinMethod()
	{
		try
		{
			//GET CONNECTION
			scon=DBConnect.getConnection();
			st=scon.createStatement();
			System.out.println("Please Enter Your Account Number");
			Account_Number=sc.nextInt();

			String sql="select * from customer where Account_Number="+Account_Number;
			rs=st.executeQuery(sql);
			if(rs.next())
			{
				//CHECK IF THE CUSTOMER REACHED LIMIT OF CHANGING THE PIN 
				if(rs.getInt(6)<5)
				{
					//IF THE LIMIT IS <5, THEN ADD +1
					int lim=rs.getInt(6)+1;
					System.out.println("***********************");
					System.out.println("Welcome "+rs.getString(3)+"."+rs.getString(4));
					System.out.println("***********************");
					System.out.println("Enter Your Old PIN number");
					int pin=sc.nextInt();
					//CHECK THE OLD PIN IS SAME OR NOT
					if(pin==rs.getInt(2))
					{
						//GET NEW PIN FROM CUSTOMER
						System.out.println("Enter Your New PIN");
						int newpin=sc.nextInt();
						String sqlnew="update customer set Customer_pin="+newpin+" where Account_Number="+Account_Number;
						int i=st.executeUpdate(sqlnew);
						if(i>0)
						{
							String sqlnewp="update account set Customer_pin="+newpin+" where Account_Number="+Account_Number;
							st.executeUpdate(sqlnewp);
							System.out.println("YOUR PIN IS CHANGED SUCCESSFULLY");
							String sql1="update customer set PinChange_Limit="+lim+" where Account_Number="+Account_Number;
							st.executeUpdate(sql1);
						}
						else
						{
							System.out.println("Please Enter Valid Pin");
						}
					}
					else
					{
						System.out.println("Incorrect Old PIN");
					}
				}
				else
				{
					System.out.println("You have Reached the Maximum Limit of Changing the pin");
					System.out.println("Please Contact Your Bank");
				}
			}
			else
			{
				System.out.println("Incorrect Account number");
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}