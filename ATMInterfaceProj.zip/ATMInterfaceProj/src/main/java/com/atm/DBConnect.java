package com.atm;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect
{
	//Database Access
	static String driver="com.mysql.cj.jdbc.Driver";
	static String url="jdbc:mysql://localhost:3306/bank";
	
	//Database Credentials
	static String un="root";
	static String pass="root";
	
	//Connection Variable
	static Connection conn=null;

	public static Connection getConnection()
	{
		try 
		{
			//Load Driver
			Class.forName(driver);
			
			//Set Connection
			conn=DriverManager.getConnection(url, un, pass);
			if(conn==null) 
			{
				//Print Message
				System.out.println("Error in connection");
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return conn;
}
}
